import React, { createContext, useContext, useState, ReactNode } from 'react';

interface DetectionResult {
  id: string;
  studentId: string;
  studentName: string;
  question: string;
  answer: string;
  submittedAt: Date;
  detectionResults: {
    plagiarismScore: number;
    aiGeneratedScore: number;
    similarityScore: number;
    externalSourcesFound: string[];
    duplicateSubmissions: string[];
    flags: string[];
  };
  status: 'clean' | 'suspicious' | 'flagged';
}

interface DetectionContextType {
  submissions: DetectionResult[];
  addSubmission: (submission: Omit<DetectionResult, 'id' | 'submittedAt'>) => DetectionResult;
  getSubmissionsByStudent: (studentId: string) => DetectionResult[];
  getAllSubmissions: () => DetectionResult[];
  runDetection: (answer: string) => Promise<DetectionResult['detectionResults']>;
}

const DetectionContext = createContext<DetectionContextType | null>(null);

export const useDetection = () => {
  const context = useContext(DetectionContext);
  if (!context) {
    throw new Error('useDetection must be used within a DetectionProvider');
  }
  return context;
};

// Mock external sources and common answers for detection
const mockExternalSources = [
  'wikipedia.org',
  'stackoverflow.com',
  'britannica.com',
  'khanacademy.org',
];

const mockAnswerDatabase = [
  'The mitochondria is the powerhouse of the cell.',
  'E=mc² represents the mass-energy equivalence.',
  'The derivative of x² is 2x.',
];

export const DetectionProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [submissions, setSubmissions] = useState<DetectionResult[]>([
    {
      id: '1',
      studentId: '1',
      studentName: 'John Student',
      question: 'Explain the role of mitochondria in cellular respiration.',
      answer: 'The mitochondria is the powerhouse of the cell, responsible for producing ATP through cellular respiration.',
      submittedAt: new Date(Date.now() - 86400000),
      detectionResults: {
        plagiarismScore: 85,
        aiGeneratedScore: 20,
        similarityScore: 90,
        externalSourcesFound: ['wikipedia.org'],
        duplicateSubmissions: [],
        flags: ['High plagiarism score', 'External source match']
      },
      status: 'flagged'
    },
    {
      id: '2',
      studentId: '1',
      studentName: 'John Student',
      question: 'What is Einstein\'s theory of relativity?',
      answer: 'Einstein\'s theory of relativity consists of two parts: special relativity and general relativity. It revolutionized our understanding of space, time, and gravity.',
      submittedAt: new Date(Date.now() - 43200000),
      detectionResults: {
        plagiarismScore: 15,
        aiGeneratedScore: 75,
        similarityScore: 20,
        externalSourcesFound: [],
        duplicateSubmissions: [],
        flags: ['Likely AI-generated content']
      },
      status: 'suspicious'
    }
  ]);

  const runDetection = async (answer: string): Promise<DetectionResult['detectionResults']> => {
    // Simulate AI detection processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    const words = answer.toLowerCase().split(' ');
    const plagiarismScore = Math.min(
      mockAnswerDatabase.reduce((max, source) => {
        const sourceWords = source.toLowerCase().split(' ');
        const commonWords = words.filter(word => sourceWords.includes(word));
        const similarity = (commonWords.length / Math.max(words.length, sourceWords.length)) * 100;
        return Math.max(max, similarity);
      }, 0),
      100
    );

    const aiGeneratedScore = Math.random() * 100;
    const similarityScore = plagiarismScore;

    const externalSourcesFound = plagiarismScore > 50 ? 
      [mockExternalSources[Math.floor(Math.random() * mockExternalSources.length)]] : [];

    const flags = [];
    if (plagiarismScore > 70) flags.push('High plagiarism score');
    if (aiGeneratedScore > 60) flags.push('Likely AI-generated content');
    if (externalSourcesFound.length > 0) flags.push('External source match');
    if (answer.length < 50) flags.push('Suspiciously short answer');

    return {
      plagiarismScore: Math.round(plagiarismScore),
      aiGeneratedScore: Math.round(aiGeneratedScore),
      similarityScore: Math.round(similarityScore),
      externalSourcesFound,
      duplicateSubmissions: [],
      flags
    };
  };

  const addSubmission = (submission: Omit<DetectionResult, 'id' | 'submittedAt'>): DetectionResult => {
    const newSubmission: DetectionResult = {
      ...submission,
      id: Date.now().toString(),
      submittedAt: new Date(),
    };

    setSubmissions(prev => [newSubmission, ...prev]);
    return newSubmission;
  };

  const getSubmissionsByStudent = (studentId: string): DetectionResult[] => {
    return submissions.filter(sub => sub.studentId === studentId);
  };

  const getAllSubmissions = (): DetectionResult[] => {
    return submissions;
  };

  return (
    <DetectionContext.Provider value={{
      submissions,
      addSubmission,
      getSubmissionsByStudent,
      getAllSubmissions,
      runDetection
    }}>
      {children}
    </DetectionContext.Provider>
  );
};