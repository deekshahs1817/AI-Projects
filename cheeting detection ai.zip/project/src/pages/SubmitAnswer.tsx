import React, { useState } from 'react';
import { FileText, Upload, AlertCircle, CheckCircle, Loader } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useDetection } from '../contexts/DetectionContext';

const SubmitAnswer: React.FC = () => {
  const { user } = useAuth();
  const { runDetection, addSubmission } = useDetection();
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || !answer.trim()) return;

    setIsAnalyzing(true);
    setAnalysisResult(null);

    try {
      const detectionResults = await runDetection(answer);
      
      const status = detectionResults.plagiarismScore > 70 || detectionResults.flags.length > 2
        ? 'flagged'
        : detectionResults.aiGeneratedScore > 60 || detectionResults.flags.length > 0
        ? 'suspicious'
        : 'clean';

      const submission = {
        studentId: user!.id,
        studentName: user!.name,
        question,
        answer,
        detectionResults,
        status: status as 'clean' | 'suspicious' | 'flagged'
      };

      addSubmission(submission);
      setAnalysisResult(detectionResults);
      setSubmitted(true);
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetForm = () => {
    setQuestion('');
    setAnswer('');
    setAnalysisResult(null);
    setSubmitted(false);
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-red-600 bg-red-100';
    if (score >= 40) return 'text-yellow-600 bg-yellow-100';
    return 'text-green-600 bg-green-100';
  };

  if (submitted && analysisResult) {
    return (
      <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-8">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-900">Analysis Complete</h1>
            <p className="text-gray-600 mt-2">Your answer has been submitted and analyzed</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className={`p-6 rounded-lg ${getScoreColor(analysisResult.plagiarismScore)}`}>
              <h3 className="font-semibold text-lg">Plagiarism Score</h3>
              <p className="text-3xl font-bold">{analysisResult.plagiarismScore}%</p>
            </div>
            <div className={`p-6 rounded-lg ${getScoreColor(analysisResult.aiGeneratedScore)}`}>
              <h3 className="font-semibold text-lg">AI Generated</h3>
              <p className="text-3xl font-bold">{analysisResult.aiGeneratedScore}%</p>
            </div>
            <div className={`p-6 rounded-lg ${getScoreColor(analysisResult.similarityScore)}`}>
              <h3 className="font-semibold text-lg">Similarity</h3>
              <p className="text-3xl font-bold">{analysisResult.similarityScore}%</p>
            </div>
          </div>

          {analysisResult.flags.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold text-red-800 mb-3">
                <AlertCircle className="inline h-5 w-5 mr-2" />
                Detected Issues
              </h3>
              <ul className="space-y-2">
                {analysisResult.flags.map((flag: string, index: number) => (
                  <li key={index} className="text-red-700">• {flag}</li>
                ))}
              </ul>
            </div>
          )}

          {analysisResult.externalSourcesFound.length > 0 && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold text-yellow-800 mb-3">
                External Sources Detected
              </h3>
              <ul className="space-y-1">
                {analysisResult.externalSourcesFound.map((source: string, index: number) => (
                  <li key={index} className="text-yellow-700">• {source}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex justify-center space-x-4">
            <button
              onClick={resetForm}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Submit Another Answer
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Submit Answer</h1>
        <p className="mt-2 text-gray-600">
          Submit your answer for automatic integrity analysis
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="question" className="block text-sm font-medium text-gray-700 mb-2">
              Question
            </label>
            <textarea
              id="question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter the question you're answering..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={3}
              required
            />
          </div>

          <div>
            <label htmlFor="answer" className="block text-sm font-medium text-gray-700 mb-2">
              Your Answer
            </label>
            <textarea
              id="answer"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Type your answer here..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={12}
              required
            />
            <p className="text-sm text-gray-500 mt-2">
              Word count: {answer.split(' ').filter(word => word.length > 0).length}
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-800">
                  Academic Integrity Notice
                </h3>
                <p className="text-sm text-blue-700 mt-1">
                  This answer will be analyzed for plagiarism, AI-generated content, and similarity to other submissions. 
                  Ensure your work is original and properly cited.
                </p>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isAnalyzing || !question.trim() || !answer.trim()}
            className="w-full flex items-center justify-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isAnalyzing ? (
              <>
                <Loader className="animate-spin h-5 w-5 mr-2" />
                Analyzing Answer...
              </>
            ) : (
              <>
                <Upload className="h-5 w-5 mr-2" />
                Submit & Analyze
              </>
            )}
          </button>
        </form>

        {isAnalyzing && (
          <div className="mt-8 bg-gray-50 rounded-lg p-6">
            <div className="text-center">
              <Loader className="animate-spin h-8 w-8 text-blue-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Analyzing Your Answer</h3>
              <p className="text-gray-600">Please wait while we run comprehensive integrity checks...</p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                  <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
                  <span>Checking for plagiarism</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                  <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse animation-delay-200"></div>
                  <span>Detecting AI-generated content</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                  <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse animation-delay-400"></div>
                  <span>Comparing with existing submissions</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SubmitAnswer;