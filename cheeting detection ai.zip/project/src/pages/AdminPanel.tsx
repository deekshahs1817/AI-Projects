import React, { useState } from 'react';
import { Settings, Users, Database, Shield, AlertCircle, CheckCircle, Activity } from 'lucide-react';
import { useDetection } from '../contexts/DetectionContext';

const AdminPanel: React.FC = () => {
  const { getAllSubmissions } = useDetection();
  const [activeTab, setActiveTab] = useState('overview');
  
  const submissions = getAllSubmissions();
  const totalUsers = 3; // Mock data
  
  const systemStats = {
    totalSubmissions: submissions.length,
    activeUsers: totalUsers,
    flaggedSubmissions: submissions.filter(s => s.status === 'flagged').length,
    systemUptime: '99.9%',
    avgResponseTime: '1.2s',
    detectionAccuracy: '96.5%'
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'detection', label: 'Detection Settings', icon: Shield },
    { id: 'system', label: 'System Config', icon: Settings },
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <div className="flex items-center">
            <Database className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-blue-600">Total Submissions</p>
              <p className="text-3xl font-bold text-blue-900">{systemStats.totalSubmissions}</p>
            </div>
          </div>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-green-600">Active Users</p>
              <p className="text-3xl font-bold text-green-900">{systemStats.activeUsers}</p>
            </div>
          </div>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <div className="flex items-center">
            <AlertCircle className="h-8 w-8 text-red-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-red-600">Flagged Submissions</p>
              <p className="text-3xl font-bold text-red-900">{systemStats.flaggedSubmissions}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">System Performance</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <p className="text-sm text-gray-600">System Uptime</p>
            <p className="text-2xl font-bold text-green-600">{systemStats.systemUptime}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-600">Avg Response Time</p>
            <p className="text-2xl font-bold text-blue-600">{systemStats.avgResponseTime}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-600">Detection Accuracy</p>
            <p className="text-2xl font-bold text-purple-600">{systemStats.detectionAccuracy}</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">User Management</h3>
      <div className="space-y-4">
        {[
          { name: 'John Student', email: 'student@demo.com', role: 'Student', status: 'Active' },
          { name: 'Prof. Smith', email: 'educator@demo.com', role: 'Educator', status: 'Active' },
          { name: 'Admin User', email: 'admin@demo.com', role: 'Admin', status: 'Active' },
        ].map((user, index) => (
          <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">{user.name}</p>
              <p className="text-sm text-gray-600">{user.email}</p>
            </div>
            <div className="flex items-center space-x-3">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                {user.role}
              </span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                {user.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderDetectionSettings = () => (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">Detection Configuration</h3>
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Plagiarism Threshold
          </label>
          <input
            type="range"
            min="0"
            max="100"
            defaultValue="70"
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-sm text-gray-600 mt-1">
            <span>0%</span>
            <span>70%</span>
            <span>100%</span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            AI Detection Sensitivity
          </label>
          <select className="w-full px-3 py-2 border border-gray-300 rounded-md">
            <option>High Sensitivity</option>
            <option>Medium Sensitivity</option>
            <option>Low Sensitivity</option>
          </select>
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            id="realtime"
            defaultChecked
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label htmlFor="realtime" className="ml-2 block text-sm text-gray-900">
            Enable real-time detection
          </label>
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            id="external"
            defaultChecked
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label htmlFor="external" className="ml-2 block text-sm text-gray-900">
            Check external sources
          </label>
        </div>
      </div>
    </div>
  );

  const renderSystemConfig = () => (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">System Configuration</h3>
      <div className="space-y-4">
        <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
          <div>
            <p className="font-medium text-gray-900">Database Backup</p>
            <p className="text-sm text-gray-600">Last backup: 2 hours ago</p>
          </div>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            Backup Now
          </button>
        </div>

        <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
          <div>
            <p className="font-medium text-gray-900">System Logs</p>
            <p className="text-sm text-gray-600">Monitor system activity</p>
          </div>
          <button className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700">
            View Logs
          </button>
        </div>

        <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
          <div>
            <p className="font-medium text-gray-900">API Settings</p>
            <p className="text-sm text-gray-600">Configure external API connections</p>
          </div>
          <button className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
            Configure
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
        <p className="mt-2 text-gray-600">
          System administration and configuration management
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <div className="lg:w-64">
          <nav className="bg-white rounded-lg shadow-md p-4">
            <ul className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <li key={tab.id}>
                    <button
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === tab.id
                          ? 'bg-blue-100 text-blue-700'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{tab.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          {activeTab === 'overview' && renderOverview()}
          {activeTab === 'users' && renderUsers()}
          {activeTab === 'detection' && renderDetectionSettings()}
          {activeTab === 'system' && renderSystemConfig()}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;