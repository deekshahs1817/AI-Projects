skill_set = [
    "Python", "Java", "C++", "React", "SQL", "AWS",
    "TensorFlow", "Node.js", "Flask", "Django",
    "HTML", "CSS", "JavaScript", "Git", "Docker", "Kubernetes"
]
