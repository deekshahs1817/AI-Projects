# parser.py

import docx
from pdfminer.high_level import extract_text


def read_pdf(path):
    return extract_text(path)

def read_docx(path):
    doc = docx.Document(path)
    return "\n".join([para.text for para in doc.paragraphs])
