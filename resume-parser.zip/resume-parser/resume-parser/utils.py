import re
import spacy

nlp = spacy.load("en_core_web_sm")

# List of common locations to ignore as names
LOCATIONS = {"Bangalore", "Mumbai", "Delhi", "Chennai", "Kolkata", "Hyderabad"}

def extract_name_by_position(text):
    lines = text.split("\n")
    for line in lines:
        clean_line = line.strip()
        if clean_line and len(clean_line.split()) <= 4:
            # Heuristic: name likely short, near top of resume
            if clean_line not in LOCATIONS:
                return clean_line
    return None

def extract_name(text):
    # First try position heuristic
    name = extract_name_by_position(text)
    if name:
        return name

    # Then try spaCy NER with location filtering
    doc = nlp(text)
    for ent in doc.ents:
        if ent.label_ == "PERSON" and ent.text not in LOCATIONS:
            return ent.text

    return None

def extract_email(text):
    match = re.search(r'\S+@\S+', text)
    return match.group() if match else None

def extract_phone(text):
    match = re.search(r'\+?\d[\d \-\(\)]{8,}\d', text)
    return match.group() if match else None

def extract_skills(text, skill_set):
    found = [skill for skill in skill_set if skill.lower() in text.lower()]
    return list(set(found))
