from flask import Flask, request, jsonify, render_template
import os

from parser import read_pdf, read_docx
from utils import extract_name, extract_email, extract_phone, extract_skills
from skills import skill_set

app = Flask(__name__)
UPLOAD_FOLDER = "resumes"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/", methods=["GET"])
def home():
    """
    Render the homepage with the resume upload form.
    """
    return render_template("index.html")

@app.route("/parse", methods=["POST"])
def parse_resume():
    """
    Handle the uploaded resume file, extract relevant information,
    and return the data as JSON.
    """
    if "resume" not in request.files:
        return jsonify({"error": "No file uploaded. Please select a resume file."}), 400

    file = request.files["resume"]
    filename = file.filename
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(file_path)

    # Extract text based on file type
    if filename.lower().endswith(".pdf"):
        text = read_pdf(file_path)
    elif filename.lower().endswith(".docx"):
        text = read_docx(file_path)
    else:
        return jsonify({"error": "Unsupported file type. Please upload a PDF or DOCX file."}), 400

    # Extract details from the resume text
    extracted_data = {
        "name": extract_name(text),
        "email": extract_email(text),
        "phone": extract_phone(text),
        "skills": extract_skills(text, skill_set)
    }

    return jsonify(extracted_data)

if __name__ == "__main__":
    app.run(debug=True)
