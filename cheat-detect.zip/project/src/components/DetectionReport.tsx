import React, { useState } from 'react';
import { AlertTriangle, CheckCircle, XCircle, Eye, Copy, Zap, FileText } from 'lucide-react';

interface DetectionCase {
  user1: string;
  user2: string;
  questionId: string;
  type: 'exact' | 'lexical' | 'semantic';
  similarity: number;
  answer1: string;
  answer2: string;
}

interface Report {
  testId: string;
  totalSubmissions: number;
  flaggedCases: DetectionCase[];
  analysisTime: string;
  timestamp: string;
}

interface DetectionReportProps {
  report: Report;
}

const DetectionReport: React.FC<DetectionReportProps> = ({ report }) => {
  const [selectedCase, setSelectedCase] = useState<DetectionCase | null>(null);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'exact':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'semantic':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'lexical':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'exact':
        return <Copy className="h-4 w-4" />;
      case 'semantic':
        return <Zap className="h-4 w-4" />;
      case 'lexical':
        return <FileText className="h-4 w-4" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Report Header */}
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-gray-900">Detection Report</h3>
          <div className="text-right">
            <p className="text-sm text-gray-500">Generated on</p>
            <p className="text-sm font-medium text-gray-900">
              {new Date(report.timestamp).toLocaleDateString()} at{' '}
              {new Date(report.timestamp).toLocaleTimeString()}
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-blue-50 p-4 rounded-xl">
            <p className="text-sm font-medium text-blue-900">Test ID</p>
            <p className="text-xl font-bold text-blue-800">{report.testId}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-xl">
            <p className="text-sm font-medium text-green-900">Total Submissions</p>
            <p className="text-xl font-bold text-green-800">{report.totalSubmissions}</p>
          </div>
          <div className="bg-red-50 p-4 rounded-xl">
            <p className="text-sm font-medium text-red-900">Flagged Cases</p>
            <p className="text-xl font-bold text-red-800">{report.flaggedCases.length}</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-xl">
            <p className="text-sm font-medium text-purple-900">Analysis Time</p>
            <p className="text-xl font-bold text-purple-800">{report.analysisTime}</p>
          </div>
        </div>

        {report.flaggedCases.length === 0 ? (
          <div className="text-center py-12">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h4 className="text-xl font-semibold text-gray-900 mb-2">No Cheating Detected</h4>
            <p className="text-gray-600">All submissions appear to be original and unique.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Users</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Question</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Type</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Similarity</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-900">Action</th>
                </tr>
              </thead>
              <tbody>
                {report.flaggedCases.map((case_, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-4">
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">{case_.user1}</div>
                        <div className="text-gray-500">vs {case_.user2}</div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-sm font-medium text-gray-900">{case_.questionId}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium border ${getTypeColor(case_.type)}`}>
                        {getTypeIcon(case_.type)}
                        <span className="capitalize">{case_.type}</span>
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${case_.similarity >= 0.95 ? 'bg-red-500' : case_.similarity >= 0.85 ? 'bg-orange-500' : 'bg-yellow-500'}`}
                            style={{ width: `${case_.similarity * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-gray-900">
                          {(case_.similarity * 100).toFixed(1)}%
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <button
                        onClick={() => setSelectedCase(case_)}
                        className="inline-flex items-center space-x-1 text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        <Eye className="h-4 w-4" />
                        <span>View Details</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Case Detail Modal */}
      {selectedCase && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="bg-gradient-to-r from-red-600 to-orange-600 px-6 py-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xl font-bold text-white">Case Details</h4>
                <button
                  onClick={() => setSelectedCase(null)}
                  className="text-white hover:text-gray-200 transition-colors"
                >
                  <XCircle className="h-6 w-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-red-50 p-4 rounded-xl">
                  <p className="text-sm font-medium text-red-900 mb-2">Detection Type</p>
                  <div className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-medium border ${getTypeColor(selectedCase.type)}`}>
                    {getTypeIcon(selectedCase.type)}
                    <span className="capitalize">{selectedCase.type} Match</span>
                  </div>
                </div>
                <div className="bg-orange-50 p-4 rounded-xl">
                  <p className="text-sm font-medium text-orange-900 mb-2">Similarity Score</p>
                  <p className="text-2xl font-bold text-orange-800">
                    {(selectedCase.similarity * 100).toFixed(1)}%
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <h5 className="text-lg font-semibold text-gray-900">Answer Comparison</h5>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 p-4 rounded-xl">
                    <h6 className="font-medium text-gray-900 mb-3">
                      {selectedCase.user1} - {selectedCase.questionId}
                    </h6>
                    <p className="text-sm text-gray-700 leading-relaxed">
                      {selectedCase.answer1}
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-xl">
                    <h6 className="font-medium text-gray-900 mb-3">
                      {selectedCase.user2} - {selectedCase.questionId}
                    </h6>
                    <p className="text-sm text-gray-700 leading-relaxed">
                      {selectedCase.answer2}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <h6 className="font-medium text-yellow-900 mb-1">Recommendation</h6>
                    <p className="text-sm text-yellow-800">
                      {selectedCase.type === 'exact' && 'This appears to be an exact copy. Investigate further for potential cheating.'}
                      {selectedCase.type === 'semantic' && 'High semantic similarity detected. The answers convey the same meaning despite different wording.'}
                      {selectedCase.type === 'lexical' && 'High lexical similarity found. The answers use very similar vocabulary and structure.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DetectionReport;