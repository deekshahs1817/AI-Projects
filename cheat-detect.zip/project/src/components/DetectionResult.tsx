import React from 'react';
import { CheckCircle, AlertTriangle, XCircle, ArrowRight, RotateCcw, Shield, Target, Users, Copy } from 'lucide-react';
import { DetectionResult as DetectionResultType } from '../App';

interface Question {
  id: number;
  question: string;
  category: string;
}

interface DetectionResultProps {
  result: DetectionResultType;
  question: Question;
  onNext: () => void;
  onRestart: () => void;
  isLastQuestion: boolean;
}

const DetectionResult: React.FC<DetectionResultProps> = ({ 
  result, 
  question, 
  onNext, 
  onRestart, 
  isLastQuestion 
}) => {
  const getResultIcon = () => {
    if (result.isCheat) {
      return <XCircle className="h-12 w-12 text-red-500" />;
    }
    return <CheckCircle className="h-12 w-12 text-green-500" />;
  };

  const getResultColor = () => {
    if (result.isCheat) {
      return 'from-red-600 to-orange-600';
    }
    return 'from-green-600 to-emerald-600';
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'copy-paste':
        return <Copy className="h-5 w-5" />;
      case 'user-copy':
        return <Users className="h-5 w-5" />;
      case 'paraphrasing':
        return <Target className="h-5 w-5" />;
      case 'multi-account':
        return <Shield className="h-5 w-5" />;
      default:
        return <CheckCircle className="h-5 w-5" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'copy-paste':
        return 'Copy-Paste Detection';
      case 'user-copy':
        return 'User Copying';
      case 'paraphrasing':
        return 'Paraphrasing Tool';
      case 'multi-account':
        return 'Multi-Account Usage';
      default:
        return 'Original Content';
    }
  };

  const getTypeDescription = (type: string) => {
    switch (type) {
      case 'copy-paste':
        return 'Answer contains phrases commonly found in AI-generated or web-sourced content';
      case 'user-copy':
        return 'High similarity detected with another user\'s submitted answer';
      case 'paraphrasing':
        return 'Patterns suggest the use of automated paraphrasing tools';
      case 'multi-account':
        return 'Similar answers detected from multiple accounts in short timeframe';
      default:
        return 'Answer appears to be original and authentic';
    }
  };

  return (
    <div className="space-y-6">
      {/* Main Result Card */}
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className={`bg-gradient-to-r ${getResultColor()} px-8 py-6`}>
          <div className="flex items-center space-x-4">
            <div className="bg-white bg-opacity-20 p-3 rounded-full">
              {getResultIcon()}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">
                {result.isCheat ? 'Cheating Detected' : 'Original Answer'}
              </h2>
              <p className="text-white text-opacity-90">
                Analysis complete with {(result.confidence * 100).toFixed(1)}% confidence
              </p>
            </div>
          </div>
        </div>

        <div className="p-8 space-y-6">
          {/* Detection Details */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-50 p-6 rounded-xl">
              <div className="flex items-center space-x-3 mb-3">
                {getTypeIcon(result.detectionType)}
                <h3 className="text-lg font-semibold text-gray-900">
                  {getTypeLabel(result.detectionType)}
                </h3>
              </div>
              <p className="text-gray-600 text-sm">
                {getTypeDescription(result.detectionType)}
              </p>
            </div>

            <div className="bg-gray-50 p-6 rounded-xl">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Confidence Score</h3>
              <div className="flex items-center space-x-3">
                <div className="flex-1 bg-gray-200 rounded-full h-3">
                  <div
                    className={`h-3 rounded-full ${result.isCheat ? 'bg-red-500' : 'bg-green-500'}`}
                    style={{ width: `${result.confidence * 100}%` }}
                  ></div>
                </div>
                <span className="text-xl font-bold text-gray-900">
                  {(result.confidence * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>

          {/* Explanation */}
          <div className={`border-l-4 ${result.isCheat ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'} p-6 rounded-r-lg`}>
            <h3 className={`text-lg font-semibold ${result.isCheat ? 'text-red-900' : 'text-green-900'} mb-2`}>
              Analysis Explanation
            </h3>
            <p className={`${result.isCheat ? 'text-red-800' : 'text-green-800'}`}>
              {result.explanation}
            </p>
          </div>

          {/* Additional Details */}
          {(result.similarityScore || result.matchedSource) && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-yellow-900 mb-3">Additional Details</h3>
              <div className="space-y-2 text-sm">
                {result.similarityScore && (
                  <div className="flex justify-between">
                    <span className="text-yellow-800">Similarity Score:</span>
                    <span className="font-medium text-yellow-900">
                      {(result.similarityScore * 100).toFixed(1)}%
                    </span>
                  </div>
                )}
                {result.matchedSource && (
                  <div className="flex justify-between">
                    <span className="text-yellow-800">Matched Source:</span>
                    <span className="font-medium text-yellow-900">{result.matchedSource}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Question Reference */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-blue-900 mb-2">Question Analyzed</h3>
            <p className="text-blue-800 mb-2">{question.question}</p>
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              {question.category}
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-center space-x-4">
        {!isLastQuestion ? (
          <button
            onClick={onNext}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-3 px-8 rounded-lg hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
          >
            Next Question
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        ) : (
          <button
            onClick={onRestart}
            className="bg-gradient-to-r from-green-600 to-emerald-600 text-white font-semibold py-3 px-8 rounded-lg hover:from-green-700 hover:to-emerald-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center"
          >
            <RotateCcw className="mr-2 h-5 w-5" />
            Start Over
          </button>
        )}
      </div>
    </div>
  );
};

export default DetectionResult;