import React, { useState } from 'react';
import { Send, User, FileText } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  category: string;
}

interface QuestionFormProps {
  question: Question;
  onSubmit: (answer: string, userId: string) => void;
  isAnalyzing: boolean;
}

const QuestionForm: React.FC<QuestionFormProps> = ({ question, onSubmit, isAnalyzing }) => {
  const [answer, setAnswer] = useState('');
  const [userId, setUserId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (answer.trim() && userId.trim()) {
      onSubmit(answer.trim(), userId.trim());
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-8 py-6">
        <div className="flex items-center space-x-3">
          <FileText className="h-6 w-6 text-white" />
          <div>
            <h2 className="text-xl font-bold text-white">Answer the Question</h2>
            <p className="text-blue-100 text-sm">Your response will be analyzed for originality</p>
          </div>
        </div>
      </div>

      <div className="p-8">
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4 leading-relaxed">
            {question.question}
          </h3>
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {question.category}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <User className="inline h-4 w-4 mr-2" />
              User ID
            </label>
            <input
              type="text"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              placeholder="Enter your unique user ID"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Your Answer
            </label>
            <textarea
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              required
              rows={8}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
              placeholder="Write your detailed answer here. Be original and use your own words..."
            />
            <div className="mt-2 flex justify-between text-sm text-gray-500">
              <span>Characters: {answer.length}</span>
              <span>Words: {answer.trim().split(/\s+/).filter(w => w.length > 0).length}</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={isAnalyzing || !answer.trim() || !userId.trim()}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-4 px-6 rounded-lg hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isAnalyzing ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                Analyzing Answer...
              </>
            ) : (
              <>
                <Send className="mr-3 h-5 w-5" />
                Submit & Analyze
              </>
            )}
          </button>
        </form>

        {/* Tips */}
        <div className="mt-6 bg-gray-50 rounded-lg p-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-2">Tips for Original Answers:</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Write in your own words and style</li>
            <li>• Avoid copying from external sources</li>
            <li>• Don't use paraphrasing tools</li>
            <li>• Each user should provide unique responses</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default QuestionForm;