import React, { useState } from 'react';
import { Shield, Brain, AlertTriangle, CheckCircle } from 'lucide-react';
import QuestionForm from './components/QuestionForm';
import DetectionResult from './components/DetectionResult';

export interface DetectionResult {
  isCheat: boolean;
  confidence: number;
  detectionType: 'copy-paste' | 'user-copy' | 'paraphrasing' | 'multi-account' | 'clean';
  explanation: string;
  similarityScore?: number;
  matchedSource?: string;
}

function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const questions = [
    {
      id: 1,
      question: "What is artificial intelligence and how does it work?",
      category: "Technology"
    },
    {
      id: 2,
      question: "Explain the concept of machine learning in simple terms.",
      category: "Technology"
    },
    {
      id: 3,
      question: "What are the main benefits of renewable energy sources?",
      category: "Environment"
    },
    {
      id: 4,
      question: "Describe the process of photosynthesis and its importance.",
      category: "Science"
    },
    {
      id: 5,
      question: "What is the significance of the water cycle in nature?",
      category: "Science"
    }
  ];

  const handleAnswerSubmit = async (answer: string, userId: string) => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis delay
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    const result = analyzeAnswer(answer, userId, questions[currentQuestion]);
    setDetectionResult(result);
    setIsAnalyzing(false);
  };

  const analyzeAnswer = (answer: string, userId: string, question: any): DetectionResult => {
    // Store answer for cross-user comparison
    const storedAnswers = JSON.parse(localStorage.getItem('userAnswers') || '[]');
    const newAnswer = {
      userId,
      questionId: question.id,
      answer: answer.toLowerCase().trim(),
      timestamp: Date.now()
    };
    storedAnswers.push(newAnswer);
    localStorage.setItem('userAnswers', JSON.stringify(storedAnswers));

    // Detection patterns for different types of cheating
    const detectionPatterns = {
      copyPaste: [
        'according to chatgpt',
        'as an ai language model',
        'i cannot provide',
        'as per google',
        'according to wikipedia',
        'source: ',
        'copied from',
        'according to the search results'
      ],
      paraphrasing: [
        'in other words',
        'to put it simply',
        'in simple terms',
        'basically',
        'essentially',
        'fundamentally'
      ],
      commonCheating: [
        'artificial intelligence is a branch of computer science that aims to create intelligent machines',
        'machine learning is a subset of artificial intelligence',
        'renewable energy comes from natural sources',
        'photosynthesis is the process by which plants make food',
        'the water cycle is the continuous movement of water'
      ]
    };

    const answerLower = answer.toLowerCase();

    // Check for copy-paste indicators
    for (const pattern of detectionPatterns.copyPaste) {
      if (answerLower.includes(pattern)) {
        return {
          isCheat: true,
          confidence: 0.95,
          detectionType: 'copy-paste',
          explanation: `Detected copy-paste indicators: "${pattern}". This suggests the answer was copied from an external source like ChatGPT or Google.`,
          matchedSource: 'External AI/Search Engine'
        };
      }
    }

    // Check for user copying (exact matches with other users)
    const sameQuestionAnswers = storedAnswers.filter(a => 
      a.questionId === question.id && a.userId !== userId
    );

    for (const existingAnswer of sameQuestionAnswers) {
      const similarity = calculateSimilarity(answerLower, existingAnswer.answer);
      if (similarity > 0.9) {
        return {
          isCheat: true,
          confidence: similarity,
          detectionType: 'user-copy',
          explanation: `High similarity (${(similarity * 100).toFixed(1)}%) detected with another user's answer. This suggests copying between users.`,
          similarityScore: similarity,
          matchedSource: `User ${existingAnswer.userId}`
        };
      }
    }

    // Check for multi-account usage (same user, different accounts)
    const userAnswers = storedAnswers.filter(a => 
      a.questionId === question.id && 
      a.userId !== userId &&
      Math.abs(a.timestamp - Date.now()) < 300000 // Within 5 minutes
    );

    for (const userAnswer of userAnswers) {
      const similarity = calculateSimilarity(answerLower, userAnswer.answer);
      if (similarity > 0.85) {
        return {
          isCheat: true,
          confidence: 0.88,
          detectionType: 'multi-account',
          explanation: 'Detected potential multi-account usage. Similar answers submitted from different accounts within a short time frame.',
          similarityScore: similarity
        };
      }
    }

    // Check for paraphrasing tools
    let paraphrasingScore = 0;
    for (const pattern of detectionPatterns.paraphrasing) {
      if (answerLower.includes(pattern)) {
        paraphrasingScore += 0.2;
      }
    }

    // Check against common cheating answers
    for (const commonAnswer of detectionPatterns.commonCheating) {
      const similarity = calculateSimilarity(answerLower, commonAnswer);
      if (similarity > 0.8) {
        return {
          isCheat: true,
          confidence: 0.82,
          detectionType: 'paraphrasing',
          explanation: `High similarity with commonly copied answers. This suggests use of paraphrasing tools or copying from common sources.`,
          similarityScore: similarity,
          matchedSource: 'Common Knowledge Base'
        };
      }
    }

    if (paraphrasingScore > 0.4) {
      return {
        isCheat: true,
        confidence: 0.75,
        detectionType: 'paraphrasing',
        explanation: 'Multiple paraphrasing indicators detected. The answer structure suggests use of paraphrasing tools.',
        similarityScore: paraphrasingScore
      };
    }

    // If no cheating detected
    return {
      isCheat: false,
      confidence: 0.95,
      detectionType: 'clean',
      explanation: 'Answer appears to be original. No indicators of copying, paraphrasing tools, or external sources detected.'
    };
  };

  const calculateSimilarity = (text1: string, text2: string): number => {
    // Simple similarity calculation using Jaccard similarity
    const words1 = new Set(text1.split(' ').filter(w => w.length > 2));
    const words2 = new Set(text2.split(' ').filter(w => w.length > 2));
    
    const intersection = new Set([...words1].filter(x => words2.has(x)));
    const union = new Set([...words1, ...words2]);
    
    return intersection.size / union.size;
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setDetectionResult(null);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setDetectionResult(null);
    localStorage.removeItem('userAnswers');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-center space-x-3">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full shadow-lg">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900">AI Cheating Detection</h1>
              <p className="text-sm text-gray-600">Advanced answer integrity analysis</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">
                Question {currentQuestion + 1} of {questions.length}
              </span>
              <span className="text-sm text-gray-500">
                {questions[currentQuestion].category}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Question and Form */}
          {!detectionResult && (
            <QuestionForm
              question={questions[currentQuestion]}
              onSubmit={handleAnswerSubmit}
              isAnalyzing={isAnalyzing}
            />
          )}

          {/* Detection Result */}
          {detectionResult && (
            <DetectionResult
              result={detectionResult}
              question={questions[currentQuestion]}
              onNext={handleNextQuestion}
              onRestart={handleRestart}
              isLastQuestion={currentQuestion === questions.length - 1}
            />
          )}

          {/* Detection Info */}
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <div className="flex items-start space-x-3">
              <Brain className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="text-lg font-semibold text-blue-900 mb-2">How Detection Works</h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm text-blue-800">
                  <div>
                    <strong>Copy-Paste Detection:</strong> Identifies phrases commonly used by AI tools and search engines
                  </div>
                  <div>
                    <strong>User Copying:</strong> Compares answers with other users for similarity
                  </div>
                  <div>
                    <strong>Paraphrasing Tools:</strong> Detects patterns typical of automated paraphrasing
                  </div>
                  <div>
                    <strong>Multi-Account:</strong> Identifies same answers from different accounts
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;

export { DetectionResult }